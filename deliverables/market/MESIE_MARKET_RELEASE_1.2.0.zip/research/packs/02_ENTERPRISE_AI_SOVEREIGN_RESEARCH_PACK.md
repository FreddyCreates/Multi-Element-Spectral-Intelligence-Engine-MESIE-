# Research Pack 02: Sovereign Enterprise AI

**MESIE Research Series · v1.2.0**

## Thesis

Enterprise AI needs **receipt chains**, not chat logs — SOLUS memory, agent vault, load-bearing tokens (12× compression).

## Evidence

- Enterprise Execution Engine — 13-node DAG
- `mesie-enterprise-ai` — sovereign vault for minted tokens
- Token budget baseline + federated envelopes

## Key modules

`mesie/enterprise/`, `mesie/compute/token_budget.py`, `mesie/mcp/`

## Market implication

Copilot-class desks with auditable compute receipts and multi-AI federation without data egress.

## Cite

`deliverables/enterprise/ENTERPRISE_EXECUTION_ENGINE.md`