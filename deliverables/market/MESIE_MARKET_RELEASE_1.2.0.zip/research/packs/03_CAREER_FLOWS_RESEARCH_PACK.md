# Research Pack 03: Career Flows at Scale

**MESIE Research Series · v1.2.0**

## Thesis

Autonomous organizations require **persistent career substrates** — 1,000 stage-gated roles with evidence-based promotion.

## Evidence

- 1,000 careers × 5 pillars × triple protocol
- NOVA 70-career precursor with never-stop supervisor
- Career MCP public forks with CI smoke tests

## Key modules

`mesie/careers/`, `mesie/agentic/micro/career.py`

## Full paper

`deliverables/research/CAREER_MCP_TRIPLE_PROTOCOL_WORKING_PAPER.md`

## Market implication

HR tech, cyber workforce, and architecture practices gain MCP-native career APIs.