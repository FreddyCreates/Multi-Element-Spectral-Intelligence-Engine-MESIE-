# Research Pack 04: Dual-Chain Token Receipts

**MESIE Research Series · v1.2.0**

## Thesis

AI compute trust requires **layered anchoring**: local LRC → Ethereum root → ICP attestation.

## Token map

| Symbol | Tier | Chain |
|--------|------|-------|
| MESIE-LRC | Internal | Local ledger |
| MESIE-PHI | Internal | ST-φ credits |
| MESIE-ANCHOR-ETH | External | Ethereum (`MESIELRC.sol`) |
| MESIE-ANCHOR-ICP | External | ICP attestation canister |

## Evidence

- Processor LRC mint on robotics pulses
- `contracts/MESIELRC.sol` — `anchorReceiptRoot`
- `mesie/cloud/icp_bridge.py` — canister sync

## Market implication

Web3 enterprises get provable AI ops without moving spectral math on-chain.

## Cite

`deliverables/tokens/MESIE_TOKEN_MANIFEST.json`