// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

/// @title MESIELRC — MESIE Load-Bearing Receipt Chain (Ethereum anchor)
/// @notice Anchors MESIE internal LRC receipt roots from edge compute (:8750).
///         Full spectral compute stays off-chain; only hash roots publish on-chain.
contract MESIELRC {
    string public constant NAME = "MESIE Load-Bearing Receipt";
    string public constant SYMBOL = "MESIELRC";
    uint8 public constant DECIMALS = 18;

    address public owner;
    bytes32 public latestRoot;
    bytes32 public priorRoot;
    uint256 public anchorCount;

    event ReceiptAnchored(bytes32 indexed root, bytes32 indexed prior, address indexed submitter, uint256 count);

    constructor() {
        owner = msg.sender;
    }

    function anchorReceiptRoot(bytes32 root, bytes32 prior) external {
        require(root != bytes32(0), "empty root");
        priorRoot = latestRoot;
        latestRoot = root;
        anchorCount += 1;
        emit ReceiptAnchored(root, prior, msg.sender, anchorCount);
    }

    function anchorFromCalldata(bytes calldata payload) external {
        bytes32 root = keccak256(payload);
        anchorReceiptRoot(root, latestRoot);
    }
}